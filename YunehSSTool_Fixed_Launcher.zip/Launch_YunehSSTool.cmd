@echo off
setlocal
title YunehSSTool Launcher
echo Downloading YunehSSTool from GitHub...
powershell.exe -NoProfile -Command "try { Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/Yuneh21/YungehSSTool/main/YunehSSTool.ps1' -OutFile (Join-Path $env:TEMP 'YunehSSTool.ps1') -ErrorAction Stop; Write-Host 'Download successful' } catch { Write-Host ('Download error: ' + $_.Exception.Message) -ForegroundColor Red; exit 1 }"
if errorlevel 1 goto failed
echo Launching YunehSSTool...
powershell.exe -NoProfile -STA -File "%TEMP%\YunehSSTool.ps1"
if errorlevel 1 goto failed
exit /b 0
:failed
echo.
echo YunehSSTool could not start. Windows may have blocked access.
echo The error above should help identify which permission is needed.
pause
exit /b 1
