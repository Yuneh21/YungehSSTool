using System.Windows;
namespace YungehSS;
public partial class App : Application { }
