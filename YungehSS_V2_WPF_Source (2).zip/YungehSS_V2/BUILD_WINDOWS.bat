@echo off
cd /d "%~dp0"
where dotnet >nul 2>&1
if errorlevel 1 (
 echo .NET 8 SDK is required. Install it from https://dotnet.microsoft.com/download/dotnet/8.0
 pause
 exit /b 1
)
dotnet publish YungehSS.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:EnableCompressionInSingleFile=true -o publish
if errorlevel 1 (
 echo Build failed. Copy the error output for troubleshooting.
 pause
 exit /b 1
)
echo Build complete. Open publish\YungehSS.exe
pause
