using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
namespace YungehSS;
public partial class MainWindow : Window
{
    private readonly Dictionary<string, (string title, string description)[]> groups = new()
    {
        ["Overview"] = new[] { ("Minecraft", "Minecraft game and mod checks"), ("Macro Detectors", "Automation and peripheral tools"), ("Windows Checks", "Processes and system diagnostics") },
        ["Minecraft"] = new[] { ("Minecraft Processes", "Identify running game and launcher processes"), ("Installed Minecraft Mods", "List JAR files in Minecraft's mods folder"), ("Outside Mods Folder", "Review JAR files in Desktop and Downloads"), ("Minecraft Versions", "List local Minecraft version folders"), ("Minecraft Logs", "List local Minecraft log filenames") },
        ["Macro Detectors"] = new[] { ("Macro Software", "Review known automation applications"), ("Peripheral Software", "Review mouse and keyboard utility processes"), ("Java Processes", "List active Java processes") },
        ["Windows Checks"] = new[] { ("Running Processes", "Show active processes"), ("System Information", "Show basic operating system information"), ("Java Executables", "Find Java commands available on PATH") }
    };
    private bool consent;
    public MainWindow() { InitializeComponent(); ShowCategory("Overview"); Log("Dashboard ready. Choose a category."); }
    private void Log(string message) { ActivityLog.AppendText($"[{DateTime.Now:HH:mm:ss}] {message}{Environment.NewLine}"); ActivityLog.ScrollToEnd(); }
    private void Category_Click(object sender, RoutedEventArgs e) { if (sender is Button b && b.Tag is string s) ShowCategory(s); }
    private void ShowCategory(string category)
    {
        PageTitle.Text = category;
        PageDescription.Text = category == "Overview" ? "Choose a category to browse the scanners." : "Click any detector to open its own scan window.";
        DetectorCards.Children.Clear();
        foreach (var item in groups[category])
        {
            var stack = new StackPanel();
            stack.Children.Add(new TextBlock { Text = item.title, FontSize = 16, FontWeight = FontWeights.SemiBold, Foreground = Brushes.White, TextWrapping = TextWrapping.Wrap });
            stack.Children.Add(new TextBlock { Text = item.description, FontSize = 12, Foreground = new SolidColorBrush(Color.FromRgb(151, 175, 202)), Margin = new Thickness(0, 9, 0, 0), TextWrapping = TextWrapping.Wrap });
            stack.Children.Add(new TextBlock { Text = category == "Overview" ? "OPEN CATEGORY  →" : "OPEN SCANNER  →", FontSize = 11, FontWeight = FontWeights.Bold, Foreground = new SolidColorBrush(Color.FromRgb(55, 163, 255)), Margin = new Thickness(0, 22, 0, 0) });
            var button = new Button { Content = stack, Width = 248, Height = 157, Margin = new Thickness(0, 0, 16, 16), Padding = new Thickness(18), Tag = item.title, VerticalContentAlignment = VerticalAlignment.Center };
            button.Click += (_, _) => { if (button.Tag is string name) { if (category == "Overview") ShowCategory(name); else OpenScanner(name); } };
            DetectorCards.Children.Add(button);
        }
        Log($"Opened {category}.");
    }
    private void OpenScanner(string name)
    {
        if (!consent)
        {
            var result = MessageBox.Show("Run local, read-only checks on this PC? Only scan a device you own or have permission to inspect. No results are uploaded.", "Permission to scan", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result != MessageBoxResult.Yes) { Log("Scan cancelled: permission not granted."); return; }
            consent = true;
        }
        Log($"Started {name}.");
        var scanner = new ScannerWindow(name) { Owner = this };
        scanner.ScanFinished += (_, _) => Log($"Finished {name}.");
        scanner.Show();
    }
}
