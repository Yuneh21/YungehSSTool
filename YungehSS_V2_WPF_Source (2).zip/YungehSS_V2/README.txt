YUNGEH SS TOOL V2 - WINDOWS WPF SOURCE

1. Install .NET 8 SDK for Windows if you don't have it.
2. Extract this ZIP on Windows.
3. Double-click BUILD_WINDOWS.bat.
4. After a successful build, open publish\YungehSS.exe.

The app is local-only and read-only. It requests consent before the first scan.
Minecraft folders, Java processes, known automation process names, and selected local JAR files can be reviewed. No detection is proof of cheating, and not all clients or profiles are covered.

This ZIP contains SOURCE CODE and a build script, not a precompiled executable. Building on Windows is required. The WPF UI has not been runtime-tested in this environment.
