using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Threading;
using Microsoft.Win32;
namespace YungehSS;
public partial class ScannerWindow : Window
{
    public event EventHandler? ScanFinished;
    private readonly string detector;
    private string[] lines = Array.Empty<string>();
    private int current;
    private readonly DispatcherTimer timer = new() { Interval = TimeSpan.FromMilliseconds(38) };
    public ScannerWindow(string name)
    {
        InitializeComponent(); detector = name; ScanTitle.Text = name; Title = $"Yungeh Scanner • {name}";
        timer.Tick += (_, _) => NextLine();
        Loaded += async (_, _) => await StartScan();
        Closed += (_, _) => timer.Stop();
    }
    private async Task StartScan()
    {
        Output.Text = $"[INFO] Preparing {detector}...{Environment.NewLine}";
        Status.Text = "Scanning...";
        try { lines = await Task.Run(() => Collect(detector).ToArray()); }
        catch (Exception ex) { lines = new[] { $"[ERROR] {ex.Message}" }; }
        timer.Start();
    }
    private void NextLine()
    {
        if (current < lines.Length)
        {
            Output.AppendText(lines[current++] + Environment.NewLine);
            Output.ScrollToEnd();
            Progress.Value = 100.0 * current / Math.Max(1, lines.Length);
        }
        else
        {
            timer.Stop(); Progress.Value = 100; Status.Text = "Scan complete • Review findings"; SaveButton.IsEnabled = true; ScanFinished?.Invoke(this, EventArgs.Empty);
        }
    }
    private static IEnumerable<string> Collect(string name)
    {
        var result = new List<string> { $"[SCAN] {name}", $"[TIME] {DateTime.Now:yyyy-MM-dd HH:mm:ss}", "[INFO] Informational matches are not proof of cheating.", "------------------------------------------------" };
        string mc = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), ".minecraft");
        void ListProcesses(string pattern)
        {
            var matches = Process.GetProcesses().Where(p => { try { return System.Text.RegularExpressions.Regex.IsMatch(p.ProcessName, pattern, System.Text.RegularExpressions.RegexOptions.IgnoreCase); } catch { return false; } }).OrderBy(p => p.ProcessName).Take(150).ToArray();
            if (matches.Length == 0) result.Add("[INFO] No matching processes found.");
            foreach (var p in matches) { try { result.Add($"[REVIEW] {p.ProcessName}  PID {p.Id}"); } catch { } finally { p.Dispose(); } }
        }
        void ListFiles(string folder, string pattern, bool directories = false)
        {
            result.Add($"[FOLDER] {folder}");
            if (!Directory.Exists(folder)) { result.Add("[INFO] Folder not found."); return; }
            try
            {
                var items = directories ? Directory.EnumerateDirectories(folder).Take(150) : Directory.EnumerateFiles(folder, pattern, SearchOption.TopDirectoryOnly).Take(150);
                int n = 0; foreach (var item in items) { result.Add($"[FILE] {Path.GetFileName(item)}"); n++; }
                if (n == 0) result.Add("[INFO] No matches at this folder level.");
            }
            catch (Exception ex) { result.Add($"[ERROR] {ex.Message}"); }
        }
        try
        {
            switch (name)
            {
                case "Minecraft Processes": ListProcesses("minecraft|javaw?|lunar|badlion|feather|prism|modrinth|curseforge"); break;
                case "Installed Minecraft Mods": result.Add("[SECTION] IN MINECRAFT MODS"); ListFiles(Path.Combine(mc, "mods"), "*.jar"); break;
                case "Outside Mods Folder": result.Add("[SECTION] NOT IN MINECRAFT MODS"); ListFiles(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "*.jar"); ListFiles(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads"), "*.jar"); result.Add("[INFO] Only selected folders scanned; no verdicts made."); break;
                case "Minecraft Versions": ListFiles(Path.Combine(mc, "versions"), "*", true); break;
                case "Minecraft Logs": ListFiles(Path.Combine(mc, "logs"), "*.log"); break;
                case "Macro Software": ListProcesses("autohotkey|autoit|tinytask|pulover|macrorecorder|keyran"); break;
                case "Peripheral Software": ListProcesses("lghub|logioptions|razer|synapse|icue|steelseries"); break;
                case "Java Processes": ListProcesses("^javaw?$"); break;
                case "Running Processes":
                    foreach (var p in Process.GetProcesses().OrderBy(p => p.ProcessName).Take(150)) { try { result.Add($"[PROC] {p.ProcessName}  PID {p.Id}"); } catch { } finally { p.Dispose(); } } break;
                case "System Information": result.Add($"[INFO] OS: {Environment.OSVersion}"); result.Add($"[INFO] Machine: {Environment.MachineName}"); result.Add($"[INFO] 64-bit OS: {Environment.Is64BitOperatingSystem}"); result.Add($"[INFO] CPU logical cores: {Environment.ProcessorCount}"); break;
                case "Java Executables":
                    foreach (string dir in (Environment.GetEnvironmentVariable("PATH") ?? "").Split(Path.PathSeparator))
                    {
                        try { foreach (string exe in new[] { "java.exe", "javaw.exe" }) { string path = Path.Combine(dir, exe); if (File.Exists(path)) result.Add($"[JAVA] {path}"); } } catch { }
                    } break;
            }
        }
        catch (Exception ex) { result.Add($"[ERROR] {ex.Message}"); }
        result.Add("------------------------------------------------"); result.Add("[DONE] Scan complete.");
        return result;
    }
    private void Save_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new SaveFileDialog { Filter = "Text report (*.txt)|*.txt", FileName = "YungehSS-Report.txt" };
        if (dialog.ShowDialog() == true) { try { File.WriteAllText(dialog.FileName, Output.Text); } catch (Exception ex) { MessageBox.Show(ex.Message, "Export failed"); } }
    }
    private void Close_Click(object sender, RoutedEventArgs e) => Close();
}
